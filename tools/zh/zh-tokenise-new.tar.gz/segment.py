from math import log10

##@memo
def segment2(text, prev='<s>'):
    "Return (log P(words), words)"
    if not text: return 0.0, []
    candidates = [combine(log10(cPw(first,prev)), first, segment2(rem,first))
                  for first,rem in splits(text)]
    return max(candidates)

def combine(Pfirst, first, (Prem, rem)):
    "Combine first and rem results into one pair"
    return Pfirst+Prem, [first]+rem

def cPw(word, prev): 
    "P(word|prev)"
    try:
        return P2w[prev + ' ' +word]/float(Pw[prev])
    except KeyError:
        return Pw(word)

class Pdist(dict):
    "probability distribution"
    def __init__(self,data,N=None,missingfn=None):
        for key,count in data:
            self[key] = self.get(key,0)+int(count)
        self.N = float(N or sum(self.itervalues()))
        self.missingfn = missingfn or (lambda k, N: 1./N)
    def __call__(self,key):
        if key in self: return self[key]/self.N
        else: return self.missingfn(key, self.N)

def datafile(name, sep='\t'):
    "Key,value pairs from name"
    for line in file(name):
        yield line.split(sep)

def avoidlongwords(word,N):
    "Estimate probability"
    return 10./(N * 10**len(word))

def splits(text, L=20):
    "Return a list of all possible (first, rem) pairs, len(first<=L."
    return [(text[:i+1], text[i+1:])
            for i in range(min(len(text),L))]

N=1000000

Pw = Pdist(datafile('x',N),avoidlongwords)

#P2w = Pdist(datafile('count2w'),N)
